﻿using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;

namespace testovacka
{
    public partial class MainWindow : Window
    {
        // ObservableCollection pro úkoly a plán dne
        public ObservableCollection<Task> Tasks { get; set; }
        public ObservableCollection<DailyPlan> DailyPlans { get; set; }

        public MainWindow()
        {
            InitializeComponent();

            // Inicializace kolekcí
            Tasks = new ObservableCollection<Task>();
            DailyPlans = new ObservableCollection<DailyPlan>();

            this.DataContext = this; // Nastavení DataContext na MainWindow

            // Přiřazení event handlerů
            AddTaskButton.Click += AddTaskButton_Click;
            AddToPlanButton.Click += AddToPlanButton_Click;
        }

        // Metoda pro přidání nového úkolu
        private void AddTaskButton_Click(object sender, RoutedEventArgs e)
        {
            string taskDescription = NewTaskTextBox.Text;
            string deadline = DeadlineDatePicker.SelectedDate?.ToString("dd.MM.yyyy") + " " + DeadlineTimeTextBox.Text;

            if (!string.IsNullOrWhiteSpace(taskDescription) && !string.IsNullOrWhiteSpace(deadline))
            {
                Tasks.Add(new Task { TaskDescription = taskDescription, Deadline = deadline, IsCompleted = false });
                NewTaskTextBox.Clear();
                DeadlineTimeTextBox.Clear();
                DeadlineDatePicker.SelectedDate = null;
            }
            else
            {
                MessageBox.Show("Prosím vyplňte všechny údaje.");
            }
        }

        // Metoda pro přidání aktivity do plánu dne
        private void AddToPlanButton_Click(object sender, RoutedEventArgs e)
        {
            string time = TimeTextBox.Text;
            string activity = ActivityTextBox.Text;

            if (!string.IsNullOrWhiteSpace(time) && !string.IsNullOrWhiteSpace(activity))
            {
                DailyPlans.Add(new DailyPlan { Time = time, Activity = activity });
                TimeTextBox.Clear();
                ActivityTextBox.Clear();
            }
            else
            {
                MessageBox.Show("Prosím vyplňte čas a aktivitu.");
            }
        }
    }

    // Třída pro úkoly
    public class Task
    {
        public string TaskDescription { get; set; }
        public string Deadline { get; set; }
        public bool IsCompleted { get; set; }
    }

    // Třída pro plán dne
    public class DailyPlan
    {
        public string Time { get; set; }
        public string Activity { get; set; }
    }
}
